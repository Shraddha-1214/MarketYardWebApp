// TradersList.jsx
import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  CircularProgress,
  Avatar,
  Stack,
  useTheme,
} from "@mui/material";
import { People, Email, Phone, LocationOn } from "@mui/icons-material";
import axiosInstance from "../api/axios";

const TradersList = () => {
  const theme = useTheme();
  const [traders, setTraders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTraders();
  }, []);

  const fetchTraders = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await axiosInstance.get("/getUseryByRole/trader", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setTraders(response.data.users || []);
    } catch (error) {
      console.error("Failed to fetch traders:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ p: 4, background: theme.palette.background.default }}>
      {/* Header */}
      <Box display="flex" alignItems="center" mb={3}>
        <People fontSize="large" color="primary" />
        <Typography variant="h5" fontWeight="bold" color="primary" ml={1}>
          Traders List
        </Typography>
      </Box>

      {/* Loading */}
      {loading ? (
        <Box display="flex" justifyContent="center" mt={6}>
          <CircularProgress color="secondary" />
        </Box>
      ) : (
        <TableContainer
          component={Paper}
          sx={{
            borderRadius: 3,
            boxShadow: 4,
            overflow: "hidden",
          }}
        >
          <Table>
            <TableHead
              sx={{
                backgroundColor: theme.palette.primary.light,
              }}
            >
              <TableRow>
                <TableCell sx={{ color: "#000" }}>
                  <strong>#</strong>
                </TableCell>
                <TableCell sx={{ color: "#000" }}>
                  <People
                    fontSize="small"
                    sx={{ verticalAlign: "middle", mr: 0.5 }}
                  />
                  Name
                </TableCell>
                <TableCell sx={{ color: "#000" }}>
                  <Email
                    fontSize="small"
                    sx={{ verticalAlign: "middle", mr: 0.5 }}
                  />
                  Email
                </TableCell>
                <TableCell sx={{ color: "#000" }}>
                  <Phone
                    fontSize="small"
                    sx={{ verticalAlign: "middle", mr: 0.5 }}
                  />
                  Phone
                </TableCell>
                <TableCell sx={{ color: "#000" }}>
                  <LocationOn
                    fontSize="small"
                    sx={{ verticalAlign: "middle", mr: 0.5 }}
                  />
                  Address
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {traders.length > 0 ? (
                traders.map((trader, index) => {
                  // compute initials for avatar
                  const initials = trader.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .toUpperCase();
                  return (
                    <TableRow
                      key={trader._id}
                      hover
                      sx={{
                        transition: "background 0.3s",
                        "&:hover": {
                          backgroundColor: theme.palette.action.hover,
                        },
                      }}
                    >
                      <TableCell>{index + 1}</TableCell>
                      <TableCell>
                        <Stack direction="row" alignItems="center" spacing={1}>
                          <Avatar
                            sx={{
                              bgcolor: theme.palette.secondary.main,
                              width: 32,
                              height: 32,
                            }}
                          >
                            {initials}
                          </Avatar>
                          <Typography>{trader.name}</Typography>
                        </Stack>
                      </TableCell>
                      <TableCell>
                        <Typography noWrap>{trader.email}</Typography>
                      </TableCell>
                      <TableCell>
                        <Typography noWrap>{trader.phone}</Typography>
                      </TableCell>
                      <TableCell>
                        <Typography noWrap>{trader.address || "—"}</Typography>
                      </TableCell>
                    </TableRow>
                  );
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={5} align="center" sx={{ py: 4 }}>
                    <Typography color="textSecondary">
                      No traders found.
                    </Typography>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Box>
  );
};

export default TradersList;
